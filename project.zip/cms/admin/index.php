<?php include "includes/admin_header.php"; ?>
    <div id="wrapper">

        <!-- Navigation -->
       <?php include "includes/admin_navigation.php"; ?>
        
        
        
        
        

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            WELCOME TO CHARITY APP 
                            <small><?php echo $_SESSION['username']; ?></small>
                        </h1>
                        <br />
                        

<div class="container">
	<div class="row">
		<div class="col-sm-3">
    	    <div class="hero-widget well well-sm">
                <div class="icon">
                     <i class="fa fa-user" aria-hidden="true"></i>

                </div>
                <div class="text">
                    <var><?php
                        $query="SELECT * FROM users WHERE user_role='admin'";
                        $select_users=mysqli_query($connection,$query);
                        $count_users=mysqli_num_rows($select_users);
                        echo $count_users;
                        ?></var>
                    <label class="text-muted">ADMINS</label>
                </div>
                
            </div>
		</div>
        <div class="col-sm-3">
            <div class="hero-widget well well-sm">
                <div class="icon">
                     <i class="fa fa-users" aria-hidden="true"></i>

                </div>
                <div class="text">
                    <var><?php
                        $query="SELECT * FROM users WHERE user_role='subscriber'";
                        $select_users=mysqli_query($connection,$query);
                        $count_users=mysqli_num_rows($select_users);
                        echo $count_users;
                        ?></var>
                    <label class="text-muted">SUBSCRIBERS</label>
                </div>
               
            </div>
		</div>
        <div class="col-sm-3">
            <div class="hero-widget well well-sm">
                <div class="icon">
                     <i class="fa fa-clipboard" aria-hidden="true"></i>

                </div>
                <div class="text">
                    <var><?php
                        $query="SELECT * FROM posts";
                        $select_posts=mysqli_query($connection,$query);
                        $count_posts=mysqli_num_rows($select_posts);
                        echo $count_posts;
                        ?></var>
                    <label class="text-muted">POSTS</label>
                </div>
                
            </div>
    	</div>
        <div class="col-sm-3">
            <div class="hero-widget well well-sm">
                <div class="icon">
                     <i class="glyphicon glyphicon-cog"></i>
                </div>
                <div class="text">
<!--                    <var></var>-->
                    <label class="text-muted">SETTINGS</label>
                </div>
                <div class="options">
                    <a href="profile.php" class="btn btn-default btn-lg"><i class="glyphicon glyphicon-wrench"></i> EDIT PROFILE</a>
                </div>
            </div>
		</div>
	</div>
</div>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        
        
        
        <!-- /#page-wrapper -->

   <?php include "includes/admin_footer.php"?>