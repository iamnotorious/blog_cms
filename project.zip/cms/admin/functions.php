<?php
function insert_categories()
{
    global $connection;
    if(isset($_POST['submit']))
                            {
                                $cat_title=$_POST['cat_title'];
                                if($cat_title==""||empty($cat_title))
                                {
                                    echo "category cant be empty";
                                }
                                else
                                {
                                   $query="INSERT INTO catagories(cat_title) VALUE('{$cat_title}')";
                            $Create_categories=mysqli_query($connection,$query);
                                    if(!$Create_categories)
                                    {
                                        die('QUERY FAILED'.mysqli_error($connection));
                                    }
                                }
                                
                            }
                            
}

function findAllCategories()
{
    global $connection;
    $query="SELECT * FROM catagories";
                            $select_categories=mysqli_query($connection,$query);
                                while($row=mysqli_fetch_assoc($select_categories))
                            {
                                $cat_id=$row['cat_id'];
                                $cat_title=$row['cat_title'];
                                echo "<tr>";
                                echo "<td>{$cat_id}</td>";
                                echo "<td>{$cat_title}</td>";
                                echo "<td><a href='categories.php?delete={$cat_id}'>DELETE</a></td>";
                                echo "<td><a href='categories.php?edit={$cat_id}'>EDIT</a></td>";
                                
                                echo "</tr>";
                            }
}
function deleteCategories()
{
    global $connection;
    if(isset($_GET['delete']))
                                {
                                   $the_cat_id= $_GET['delete'];
                                    $query="DELETE FROM catagories WHERE cat_id= {$the_cat_id}";
                                    $delete_query=mysqli_query($connection,$query);
                                    header("location:categories.php");
                                }
                                
}

?>