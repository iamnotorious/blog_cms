<?php

if(isset($_GET['user']))
{
    $the_user_id=$_GET['user'];
    $query="SELECT * FROM users WHERE user_id={$the_user_id}";
    
    $select_users_query_edit=mysqli_query($connection,$query);
    
    while($row=mysqli_fetch_assoc($select_users_query_edit))
    {
    $user_id=$row['user_id'];
    $user_name=$row['user_name'];

    $user_password=$row['user_password'];

    $user_firstname=$row['user_firstname'];
    $user_lastname=$row['user_lastname'];
    $user_email=$row['user_email'];
    $user_image=$row['user_image'];
    $user_role =$row['user_role'];
    $user_password=$row['user_password'];
     
    }
}
if(isset($_POST['edit_user']))
 {
    $user_name=$_POST['username'];

    $user_password=$_POST['password'];

    $user_firstname=$_POST['user_firstname'];
    $user_lastname=$_POST['user_lastname'];
    $user_email=$_POST['email'];
    
    $user_role =$_POST['user_role'];


//     move_uploaded_file($post_image_temp,"../images/$post_image");
//     
        $query="UPDATE users SET ";
        $query.="user_name = '{$user_name}', ";
        $query.="user_password = '{$user_password}', ";
        $query.="user_firstname = '{$user_firstname}', ";
        $query.="user_lastname = '{$user_lastname}', "; 
        $query.="user_email = '{$user_email}', "; 
        $query.="user_role = '{$user_role}' ";
        $query.="WHERE user_id = {$the_user_id}";
    
    $update_user=mysqli_query($connection,$query);
    if(!$update_user)
    {
        die("query failed".mysqli_error($connection));
    }
     
 }
  ?>
   <form action="" method="post" enctype="multipart/form-data">
    <div class="form_group">
        <label for="FirstName">FIRST NAME</label>
        <input value="<?php echo $user_firstname; ?>" type="text" class="form-control" name="user_firstname">
    </div>
    
     <div class="form_group">
        <label for="LastName">LAST NAME</label>
        <input type="text" class="form-control" value="<?php echo $user_lastname; ?>" name="user_lastname">
    </div>
    
    <div class="form-group">
        <label for="user_role">ROLE</label>
        <select name="user_role" id="">
        <?php
//        $query="SELECT * FROM users";
//            $result=mysqli_query($connection,$query);
//            if(!$result)
//            {
//                die(mysqli_error($connection));
//            }
//            while($row=mysqli_fetch_assoc($result))
//            {
//                $user_id=$row['user_id'];
//                $user_role=$row['user_role'];
//               echo "<option value="subscriber">SELECT OPTION</option>"
      
//            }
        ?>
        <option value="<?php echo $user_role;?>"><?php echo $user_role;?></option>
        
        <?php
            if($user_role=='admin')
            {
          echo "<option value='subscriber'>subscriber</option>";
            }
                else if($user_role=='subscriber')
            
                {echo "<option value='admin'>ADMIN</option>";
            
                }?>
        
        </select>
    </div>
        
      
<!--
    
    <div class="form-group">
        <label for="post_image">Post Image</label>
        <input type="file"  name="image">
    </div>
-->
   
    <div class="form-group">
        <label for="Username">USERNAME</label>
        <input value="<?php echo $user_name; ?>" type="text" class="form-control" name="username">
    </div>
    <div class="form-group">
        <label for="Email">EMAIL</label>
       <input type="text" value="<?php echo $user_email; ?>" class="form-control" name="email">
    </div>
    <div class="form-group">
        <label for="password">PASSWORD</label>
       <input type="password" value="<?php echo $user_password; ?>" class="form-control" name="password">
    </div>
    <div class="form-group">
        
        <input type="submit" class="btn btn-primary" type="submit" name="edit_user" value="UPDATE USER">
    </div>
    
</form>