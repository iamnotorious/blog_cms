<table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>USERNAME</th>
                                    <th>FIRSTNAME</th>
                                    <th>LASTNAME</th>
                                    <th>EMAIL</th>
                                    <th>ROLE</th>
                                    <th>DATE</th>
                                    <th>EDIT</th>
                                    <th>DELETE</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                   <?php
                                $query="SELECT * FROM users";
                            $select_users=mysqli_query($connection,$query);
                                while($row=mysqli_fetch_assoc($select_users))
                            {
                                $user_id=$row['user_id'];
                                $user_name=$row['user_name'];
                                
                                $user_password=$row['user_password'];
                              
                              $user_firstname=$row['user_firstname'];
                                $user_lastname=$row['user_lastname'];
                                $user_email=$row['user_email'];
                                $user_image=$row['user_image'];
                                $user_role =$row['user_role'];
                               
                                
                                echo "<tr>";
                                echo"<td>$user_id</td>";
                                echo"<td>$user_name</td>"; 
                                echo"<td>$user_firstname</td>"; 
                                
//                                $query="SELECT * FROM catagories WHERE cat_id=$post_category_id";
//            $result=mysqli_query($connection,$query);
//            if(!$result)
//            {
//                die(mysqli_error($connection));
//            }
//            while($row=mysqli_fetch_assoc($result))
//            {
//                $cat_id=$row['cat_id'];
//                $cat_title=$row['cat_title'];
//                echo"<td>$cat_title</td>"; 
//               
//            }
                                
                                
                                echo"<td>$user_lastname</td>";
                                
                                echo"<td>$user_email</td>"; 
                                 
                                echo"<td>$user_role</td>"; 
                                echo"<td>$</td>";
                                echo"<td><a href='users.php?source=edit_user&user= {$user_id}'>EDIT</a></td>";
                                
                                echo"<td><a href='users.php?delete='{$user_id}'>DELETE</a></td>";
                                
                                    
                                echo "</tr>";
                            }
                                ?>
                                   
                                    
                                
                            </tbody>
                        </table>


<?php 
if(isset($_GET['delete']))
{
    $delete_id=$_GET['delete'];
     
    $query="DELETE FROM users WHERE user_id = {$user_id}";
    $result = mysqli_query($connection,$query);
    if(!$result)
    {
    die($connection);
    }
}
?>