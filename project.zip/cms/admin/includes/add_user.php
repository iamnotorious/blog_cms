<?php
 if(isset($_POST['add_user']))
 {
    $user_name=$_POST['username'];

    $user_password=$_POST['password'];

    $user_firstname=$_POST['user_firstname'];
    $user_lastname=$_POST['user_lastname'];
    $user_email=$_POST['email'];
    
    $user_role =$_POST['user_role'];


//     move_uploaded_file($post_image_temp,"../images/$post_image");
//     
     $query = "INSERT INTO users(user_firstname,user_lastname,user_role,user_name,user_email,user_password) "; 
     $query.="VALUES('{$user_firstname}','{$user_lastname}','{$user_role}','{$user_name}','{$user_email}','{$user_password }')";
     $result=mysqli_query($connection,$query);
     
     if(!$result)
     {
         die("query failed".mysqli_error($connection));
     }
     
 }
  ?>
   <form action="" method="post" enctype="multipart/form-data">
    <div class="form_group">
        <label for="FirstName">FIRST NAME</label>
        <input type="text" class="form-control" name="user_firstname">
    </div>
    
     <div class="form_group">
        <label for="LastName">LAST NAME</label>
        <input type="text" class="form-control" name="user_lastname">
    </div>
    
    <div class="form-group">
        <label for="user_role">ROLE</label>
        <select name="user_role" id="">
        <?php
//        $query="SELECT * FROM users";
//            $result=mysqli_query($connection,$query);
//            if(!$result)
//            {
//                die(mysqli_error($connection));
//            }
//            while($row=mysqli_fetch_assoc($result))
//            {
//                $user_id=$row['user_id'];
//                $user_role=$row['user_role'];
//               echo "<option value='$user_id'>{$user_role}</option>";
//            }
        ?>
        <option value="subscriber">SELECT OPTION</option>
        <option value="admin">ADMIN</option>
        <option value="subscriber">SUBSCRIBER</option>
      
        
        </select>
    </div>
        
      
<!--
    
    <div class="form-group">
        <label for="post_image">Post Image</label>
        <input type="file"  name="image">
    </div>
-->
   
    <div class="form-group">
        <label for="Username">USERNAME</label>
        <input type="text" class="form-control" name="username">
    </div>
    <div class="form-group">
        <label for="Email">EMAIL</label>
       <input type="text" class="form-control" name="email">
    </div>
    <div class="form-group">
        <label for="password">PASSWORD</label>
       <input type="text" class="form-control" name="password">
    </div>
    <div class="form-group">
        
        <input type="submit" class="btn btn-primary" type="submit" name="add_user" value="ADD USER">
    </div>
    
</form>