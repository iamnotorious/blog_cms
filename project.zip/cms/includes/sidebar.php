<div class="col-md-4">

               
               
               
               
                <!-- Blog Search Well -->
                <!--<div class="well">
                    <h4>Blog Search</h4>
                    <form action="search.php" method="post">
                    <div class="input-group">
                        <input name="search" type="text" class="form-control">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="submit" name="submit">
                                <span class="glyphicon glyphicon-search"></span>
                        </button>
                        </span>
                    </div>
                   </form>
                   
                </div> -->
                    
                    <!-- LOGING form -->
                    <?php 
    error_reporting(0);
    if($_SESSION['username']==null) 
                    { ?>
                    <div class="well">
                    <h4>LOGIN</h4>
                    <form action="includes/login.php" method="post">
                    <div class="form-group">
                        <input name="username" placeholder="ENTER USERNAME" type="text" class="form-control">
                        
                    </div>
                    
                     <div class="input-group">
                        <input name="password" placeholder="ENTER PASSWORD" type="password" class="form-control">
                        <span class="input-group-btn">
                            <button class="btn btn-primary" name="login" type="submit">
                                LOGIN
                            </button>
                        </span>
                        
                    </div>
    
                        </form></div>
                     <?php   }
                            else if($_SESSION['username']!==null)
                        {
                            $first_name=$_SESSION['firstname'];
                            
                        
                        ?>
                        <form action="" method="post">
                        <div class="well">
                        <h4>WELCOME :</h4>
                        <?php
                        echo $first_name;
                        ?>
                        <hr>
                        <span class="input-group-btn">
                            <button class="btn btn-primary" name="logout" type="submit">
                                LOG OUT
                            </button>
                        </span>
                    </div>
                    </form>
                    <?php
                        if(isset($_POST['logout']))
                        {
                        $_SESSION['username'] = null;
                        $_SESSION['firstname'] = null ;
                        $_SESSION['lastname'] = null;
                        $_SESSION['user_role'] = null;
                        
                        }
                        }
                    ?>

               
               
               
                <!-- Blog Categories Well -->
                <div class="well">
                   <?php
                    $query="SELECT * FROM catagories";
                    $select_catagories_sidebar=mysqli_query($connection,$query);
                    
                   
                    ?>
                    <h4>Blog Categories</h4>
                    <div class="row">
                        <div class="col-lg-12">
                            <ul class="list-unstyled">
                               <?php while($row=mysqli_fetch_assoc($select_catagories_sidebar))
                    {
                        $cat_id=$row['cat_id'];
                        $cat_title=$row['cat_title'];
                        echo "<li><a href='index_cat.php?cat={$cat_id}'>{$cat_title}</a></li>";
                     ?>
                           <?php }?>
                            </ul>
                            
                        </div>
                        
                        
                       
                        
                    </div>
                    <!-- /.row -->
                </div>

                <!-- Side Widget Well -->
                <div class="well">
                    <h4>ABOUT US</h4>
                    <p>We host this website,as a medium to reach people who want to do some good in this world by helping needy people. come and join us in this program and start helping people who needs you :) 
                      <h3>PRMCEAM</h3>
                    </p>
                </div>

            </div>

    