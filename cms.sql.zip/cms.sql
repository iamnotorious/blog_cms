--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `catagories`
--

CREATE TABLE `catagories` (
  `cat_id` int(3) NOT NULL,
  `cat_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `catagories`
--

INSERT INTO `catagories` (`cat_id`, `cat_title`) VALUES
(27, 'BOOKS'),
(28, 'FOOD'),
(29, 'CLOTHS'),
(30, 'MONEY'),
(31, 'HEALTH AND MOBILITY');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(3) NOT NULL,
  `post_catagory_id` int(3) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_author` varchar(255) NOT NULL,
  `post_date` date NOT NULL,
  `post_image` text NOT NULL,
  `post_content` text NOT NULL,
  `post_tags` varchar(255) NOT NULL,
  `post_comment_count` varchar(255) NOT NULL,
  `post_status` varchar(255) NOT NULL DEFAULT 'draft'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `post_catagory_id`, `post_title`, `post_author`, `post_date`, `post_image`, `post_content`, `post_tags`, `post_comment_count`, `post_status`) VALUES
(16, 28, 'FOOD FOR EDUCATION - SHRI SAI VIDHYALAYA  ', 'SHUBHAM SHEREKAR', '2017-04-10', 'donate.jpg', 'FOOD FOR EDUCATION - SHRI SAI VIDHYALAYA\r\n We have been giving meals to the Shri Sai Vidhyalaya school since January 2010, under our Food for Education program. \r\nThe school is located in Mankhurd area, where there are not too many registered schools. Thus, inspite of a space constraint the school works in two shifts so that they can cater to many children. IN this way the schools is providing significant contribution in educational service.\r\n\r\nCONTACT : http://www.ratnanidhi.org/food-for-education/shri-sai-vidhyalaya/', 'FOOD,EDUCATION', '4', 'CROWD FUNDING'),
(17, 31, 'HELP DISABLED IN HEALTH & MOBILITY ', 'AALHAD WELANKIWAR', '2017-04-10', '764497674_Photo shop.jpg', 'By means of the mobility and hearing aids project, Ratna Nidhi Charitable trust aims to bequeath a new life to each of those who have been deprived of the basic privileges of mobility and hearing for most of their lives. With the gift of mobility, these people develop self confidence, have the abilities to lead near normal lives and have the potential to become contributive members of their society instead of being a burden on it.\r\nWe have been one of the pioneers in organizing mobility camps having earlier worked in the Himalayan mountainous regions of Leh, Kargil, Srinagar, and Dharamsala, in the strategically located border areas of Rajouri and Poonch over and above the major camps in Gujarat, Maharashtra, Andhra Pradesh, Tamil Nadu and many more places across India and developing nations abroad. We have also set up a permanent centres to aid the disabled in Mumbai .\r\nTill date the we have been able to reach out to an astounding figure of over 2,23,325 disabled beneficiaries. The camp at Palitana, Gujarat in 2009-10 was the largest of its kind giving a new lease of life to 28549 poorest of the poor disabled of Bhavnagar and adjoining districts. The camp was inaugurated by Honourable Chief minister of Gujarat, Narendra Modi and was graced by the presence of His Holiness The Dalai lama.\r\nThese mobility camps provide various aids to support their mobility/audio receptivity. Children/youth affected by polio will be given calipers to support their limbs, limb amputees will be fitted with Jaipur foot prosthetics, Tricycles, wheelchairs and crutches will also be distributed on a need based assessment. People with hearing impairment will be given hearing aids in order to improve their audio receptivity.\r\nWe have a fleet of custom built Mobile Orthopaedic Hospital Vans and a special van for the Hearing impaired all fully equipped and manned by teams of trained and experienced personnel who fabricate prosthetics within a matter of hours so that a patient who enters the camp with the support from a family member in the morning, walks out independently by early evening.', 'HEALTH & MOBILITY', '4', 'CROWD FUNDING'),
(18, 30, 'HELP REBUILD LIVES OF 60 CHILDREN OF TERROR VICTIMS ', 'MOHIT GANDHI', '2017-04-10', 'charity_water_pouring.jpg', 'HELP REBUILD LIVES OF 60 CHILDREN OF TERROR VICTIMS\r\nIntroduction\r\nSince its inception Ratna Nidhi Charitable Trust has been working in the field of education. Our education scholarship program was commenced understanding the need to support children and families of terror attacks in Mumbai. Through this project we strive to break the barriers towards acquisition of education for the deprived & underprivileged section. \r\nRNCT Education Scholarship Program\r\nIn the past 15 years our city has witnessed the most daunting terror attacks, costing the lives of many innocents. Time and again we have shown our spirits of togetherness and helped each other during such challenging stages. However, families of these terror victims were shattered with the sudden financial responsibilities. And in such situations it is undeniable that the childrenâ€™s education takes a back step, further impacting their future.\r\nIdentifying the post terror impact on these little ones, Ratna Nidhi started Education Scholarship Program to support their education. The first set of scholarships was provided to the victims of Mumbai terror attack which took place on August 24, 2003. Till date this project has successfully covered 300 children, out of which, many of them have completed their education with flying colors.\r\nYou take home!  \r\nWhen you support a child from our Education Sponsorship Program, you are already creating huge impact in their life. Your investment will lead to future leaders of our community, who are looking forward to complete their dream.\r\nIn addition to experience the joy of giving, you will find your contribution has tangible benefits as well. We would be happy to provide you with an 80G receipt and a thank you certificate as a small token of appreciation from our end.\r\nSuccess Story:\r\n\r\n Anjali is still waiting to complete her dream. Here is her life story.\r\n At a tender age of seven, Anjali lost her father during the 26/11 Mumbai terror attacks. A garage worker by profession was shot   in his head at Chatrapati Shivaji Terminal Railway Station. Fortunately his mother survived the act but was critically injured.   Anjaliâ€™s younger sister Nikita was just two year old during that period. Her mother Savitriâ€™s world comes crashing down with the sudden loss along with the responsibility of two young daughters and ailing mother in law.\r\nSavitiri with a limited family saving couldnâ€™t see a way to support her daughters education. That was the time when she was provided scholarship for her two daughters through Ratna Nidhiâ€™s Education Sponsorship Program. With the support of this program, Anjali has now reached to Class 9 and ranks second in her class.  While her sister Nikita is happily studying in Class 4.\r\nWatching her two daughter study, Savitri was also motivated to continue her education. She has now completed her 10th from a night school and works with the India Railway to support her family.\r\nIt will be a long way to go for Savitri and her daughters, but we promise to be by their side till the very end. \r\nThe Need\r\nRatna Nidhi works to provide a fair chance to every child of this project, especially to the most deprived. Therefore, with proper monitoring the progress of these children, we decide to further support 60 children out of the 300 for the span of 2 years, who are still in the process of completing their education and require guidance.\r\n\r\nCONTACT :http://www.ratnanidhi.org/Category/educational-sponsorships-for-terror-victims', 'HOMELESS,POOR PEOPLE', '4', 'CROWD FUNDING'),
(19, 27, 'akash', 'akasdh', '2017-04-10', 'Charity-Jar.jpg', 'asdsafsdf', '', '4', 'aksdh'),
(20, 27, 'akash', 'akasdh', '2017-04-10', 'Charity-Jar.jpg', 'asdsafsdf', '', '4', 'aksdh');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(3) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_firstname` varchar(255) NOT NULL,
  `user_lastname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_image` text NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `randSalt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_password`, `user_firstname`, `user_lastname`, `user_email`, `user_image`, `user_role`, `randSalt`) VALUES
(9, 'akash', '123', 'akash', 'ujjainkar', 'ujjainkarss@gmail.com', '', 'admin', ''),
(10, 'shubham', '123', 'shubham', 'sherekar', 'shubham@gmail.com', '', 'admin', ''),
(11, 'aalhad', '123', 'aalhad', 'welankiwar', 'aalhad@gmail.com', '', 'admin', ''),
(12, 'mohit', '123', 'mohit', 'gandhi', 'mohit@dr.com', '', 'admin', ''),
(13, 'abc', '123', 'prashant', 'ujjainkar', 'abc@dr.com', '', 'subscriber', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `catagories`
--
ALTER TABLE `catagories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `catagories`
--
ALTER TABLE `catagories`
  MODIFY `cat_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
